set -eu
evidence_dir=/home/johnz86/.cache/hoard-memory-evidence
mkdir -p "$evidence_dir/smoke/git"
cp "$evidence_dir/scale/tree-100000/d0/w0.safetensors" "$evidence_dir/smoke/git/w0.safetensors"
git -C "$evidence_dir/smoke/git" init -q -b main
git -C "$evidence_dir/smoke/git" add w0.safetensors
git -C "$evidence_dir/smoke/git" -c user.name=Fixture -c user.email=fixture@example.invalid commit -qm 'Seed synthetic model'
git -C "$evidence_dir/smoke/git" remote add origin https://huggingface.co/org0/repo000
for variant in baseline selected; do
    if test "$variant" = baseline; then binary=$evidence_dir/baseline-cli; else binary=$evidence_dir/selected-final-cli; fi
    config=$evidence_dir/smoke/$variant.toml
    cat > "$config" <<CONFIG
[server]
bind = "127.0.0.1:17311"
data_dir = "$evidence_dir/smoke/$variant"
[node]
name = "bench"
serve = true
discovery = "none"
[index]
hash_policy = "never"
watch = false
[[index.sources]]
name = "bench"
path = "$evidence_dir/scale/tree-100000"
kind = "loose"
repo_per_folder = true
[[index.sources]]
name = "git"
path = "$evidence_dir/smoke/git"
kind = "git"
[mirror]
offline = true
CONFIG
    "$binary" --config "$config" scan --hash never > "$evidence_dir/results/$variant-smoke-scan.log" 2>&1
    "$binary" --config "$config" ls --json --limit 1 > "$evidence_dir/results/$variant-smoke-ls.json"
    timeout 120 bash "$evidence_dir/smoke-server.sh" "$binary" "$config" > "$evidence_dir/results/$variant-smoke-routes.log" 2>&1
done
