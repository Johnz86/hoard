set -eu
evidence_dir=/home/johnz86/.cache/hoard-memory-evidence
archive=/home/johnz86/GIT/hoard/docs/evidence/memory-2026-09-08
for run in 1 2; do
    for variant in baseline selected; do
        HOARD_SCALE_DIR=$evidence_dir/shapes /usr/bin/time -v "$evidence_dir/$variant-final-scale" --ignored --exact mixed_size_hashing --nocapture > "$evidence_dir/results/$variant-final-hashing-$run.log" 2>&1
        for count in 1 4; do
            HOARD_SCALE_DIR=$evidence_dir/shapes HOARD_SCALE_WIDE_CARD_ARTIFACTS=$count /usr/bin/time -v "$evidence_dir/$variant-final-scale" --ignored --exact supplemental::wide_card_phase --nocapture > "$evidence_dir/results/$variant-final-wide-$count-$run.log" 2>&1
            cp "$evidence_dir/results/$variant-final-wide-$count-$run.log" "$archive/"
        done
        cp "$evidence_dir/results/$variant-final-hashing-$run.log" "$archive/"
        for background in off on; do
            if test "$background" = on; then export HOARD_SCALE_BACKGROUND=1; else unset HOARD_SCALE_BACKGROUND; fi
            HOARD_SCALE_CONCURRENT=1 HOARD_SCALE_ENTRIES=1000000 HOARD_SCALE_DIR=$evidence_dir/probe /usr/bin/time -v "$evidence_dir/$variant-final-scale" --ignored --exact concurrent_catalog_queries --nocapture > "$evidence_dir/results/$variant-final-direct-$background-$run.log" 2>&1
            if test "$variant" = baseline; then http=$evidence_dir/baseline-http; else http=$evidence_dir/selected-final-http; fi
            HOARD_SCALE_CONCURRENT=1 HOARD_SCALE_ENTRIES=1000000 HOARD_SCALE_DIR=$evidence_dir/probe /usr/bin/time -v "$http" --ignored --exact simultaneous_midpoint_http_requests --nocapture > "$evidence_dir/results/$variant-final-http-$background-$run.log" 2>&1
            cp "$evidence_dir/results/$variant-final-direct-$background-$run.log" "$evidence_dir/results/$variant-final-http-$background-$run.log" "$archive/"
        done
        unset HOARD_SCALE_BACKGROUND
    done
done
