Memory measurements, 2026-09-08

Final baseline: bdf2964f954f2612c5a2a0ab4d33b9361aef8e00 production.
Final selected: baseline plus results/delivery-production.patch. This is hashing and
metered indexing recovered from fef969a, with comment cleanup and constants relocated.
Source and executable SHA256 files identify the exact measured inputs.
No usage schema, summary folding, grouped discovery, or cache configuration changes remain.

Files named *-final-* are the final matched comparison. Both scales ran twice with
independently seeded catalogs over the same restored synthetic tree. Preflight logs
assert fixture execution and answers; their timings are not acceptance evidence.
The direct-query and HTTP checks use the same intact synthetic format-7 probe catalog;
they reopen it per process and the background cases rebuild it. They are query gate
checks, not a claim of a latency improvement. Reference queries precede timed requests.

Files named baseline-100000*, candidate-100000*, baseline-hashing*, candidate-hashing*,
baseline-wide*, candidate-wide*, baseline-retirement*, candidate-retirement* are earlier
full-recovery comparisons. Candidate production is 04adbd767d8cc9cbfbcf45ef1cf048bb168cba17.
Those earlier fixtures lacked separate unchanged-rescan and wide-card refresh phases.
Do not compare those phase memory values against the later final harness.
Diagnostic logs are instrumented and excluded from acceptance timings.

Reproduction from the repository containing this archive:
1. Create a detached scratch worktree at the baseline commit. Copy the current scale.rs
   and tests/memory_http.rs into it. Run adapt-harness.pl on baseline scale.rs only.
   The adapter replaces the reporting APIs unavailable on baseline. Its rebuild commit
   count is one; refresh count is ceil(applied / 4096), derived from baseline source.
   Selected uses actual reporting API counts. Work and timing boundaries are identical.
2. Before timing anything, build each variant from its own working directory:
   cargo clean --release -p hoard-index -p hoard-server
   cargo test --release -p hoard-index --features fixtures --test scale --no-run
   cargo test --release --test memory_http --no-run
   Use CARGO_TARGET_DIR only if sharing artifacts; force the package clean when switching.
   Copy the printed test executable paths and release/hoard to the variant names used in
   run-final.sh and smoke.sh before building the next variant. Never set RUSTFLAGS.
3. Set the scratch and archive destinations in the recorded scripts for your machine.
   First seed an intact query probe, with no HOARD_SCALE_DELETE or HOARD_SCALE_USAGE:
   HOARD_SCALE_DIR=<scratch>/probe HOARD_SCALE_ENTRIES=1000000 HOARD_SCALE_CONCURRENT=1
   <baseline-final-scale> --ignored --exact native_catalog_at_scale --nocapture
4. Execute run-final.sh, then smoke.sh. Each command runs serially. The scale harness
   generates/restores inputs, deletes old output catalogs, and asserts counts and answers.
   smoke.sh builds a local git fixture and runs actual CLI scans and all eleven HTTP
   routes, each three times after 2,000 successful file GETs. Servers are timeout-bound,
   terminated, and joined. No user's configuration or catalog is used.
5. Delete the generated data and remove your temporary worktrees after saving results.

All completed final workloads passed. The first query-only invocation omitted
HOARD_SCALE_CONCURRENT and correctly failed its fixture assertion; run-targeted.sh
reran the targeted phase with the required flag. No failed run is acceptance evidence.
The final CLI also opened the baseline smoke catalog and queried used:<1d with used
sorting: its one recently served artifact remained present (format7-used.log).
