set -eu
"$1" --config "$2" serve > "${2%.toml}-server.log" 2>&1 &
server_pid=$!
trap 'kill -TERM "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true' EXIT
for attempt in $(seq 1 100); do
    if curl --noproxy '*' -fsS http://127.0.0.1:17311/api/v1/sources > /dev/null; then break; fi
    sleep 0.1
done
curl --noproxy '*' -fsSI http://127.0.0.1:17311/org0/repo000/resolve/main/w0.safetensors > /dev/null
for request in $(seq 1 2000); do
    curl --noproxy '*' -fsS http://127.0.0.1:17311/org0/repo000/resolve/main/w0.safetensors > /dev/null
done
for attempt in $(seq 1 100); do
    if curl --noproxy '*' -fsS http://127.0.0.1:17311/api/v1/repos/models/org0/repo000/usage | jq -e '.total >= 2000' > /dev/null; then break; fi
    sleep 0.1
done
curl --noproxy '*' -fsS http://127.0.0.1:17311/api/v1/repos/models/org0/repo000/usage | jq -e '.total >= 2000'
for route in '/api/v1/repos?limit=1' '/api/v1/repos?limit=100' '/api/models?limit=1' '/api/models/org0/repo000' '/org0/repo000/resolve/main/w0.safetensors' '/api/v1/sources' '/api/v1/search?q=' '/api/v1/search?q=node:self' '/api/v1/search?q=role:lora' '/api/v1/triage?limit=20' '/api/v1/repos/models/org0/repo000/usage'; do
    for run in 1 2 3; do
        if test "$route" = /org0/repo000/resolve/main/w0.safetensors; then method=HEAD; curl_method=(-I); else method=GET; curl_method=(); fi
        curl --noproxy '*' -fsS "${curl_method[@]}" -o /dev/null -w "$method $route %{http_code} %{time_total}\n" "http://127.0.0.1:17311$route"
    done
done
