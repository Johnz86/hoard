use strict;
use warnings;
for my $path (@ARGV) {
    open my $input, '<', $path or die $!;
    my $source = do { local $/; <$input> };
    $source =~ s/\.rebuild_search_commits\(\|count\| indexed = count\)/.rebuild_search(|count| indexed = count).map(|()| 1_u64)/ or die 'rebuild adapter';
    $source =~ s/\.refresh_search_reporting\(\|_\| \{\}\)\s*\.map\(\|report\| \(report.applied, report.commits\)\)/.refresh_search(|_| {}).map(|applied| (applied, applied.div_ceil(4096)))/g or die 'refresh adapter';
    open my $output, '>', $path or die $!;
    print $output $source;
}
